Responsive Mobile First Web Template
------------------------------------
Author URI: http://webthemez.com/

Jack - Coming Soon Page:
Jack is a simple coming soon theme is a responsive web compatable with multi devices, comes with unlimited background colors. The countdown is powered by a custom jQuery plugin, just you need to set you launching date in the script.


Features :
--------
=> Easy to use, Heigh quality coded HTML5 and CSS3.
=> Multi device compatibility
=> Responsive design
=> jQuery Countdown plugin

Credits :
-------
=> Design and developed: "WebThemez"  http://webthemez.com 
=> For more free web themes: http://webthemez.com

License :
-------
**Creative Commons Attribution 3.0** - http://creativecommons.org/licenses/by/3.0/

**Free to use for personal and commercial, but you need to place back link in the bottom of the template(Template by: webthemez.com).
